<?php

$conn = mysqli_connect('localhost','root','','user_db') or die('connection failed');


?>

<?php 
/*
<?php
$host = "sql101.unaux.com";
$user = "unaux_34858025";
$pass = "lr9sgl";
$db = "unaux_34858025_user_db";

$conn = mysqli_connect($host,$user,$pass,$db) or die('connection failed');

?>

*/
 ?>

